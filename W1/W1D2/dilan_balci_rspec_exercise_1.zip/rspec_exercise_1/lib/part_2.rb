
def vowel_counts(str)

    counter = Hash.new(0)
    vovels = "aeiou"

    str.each_char do |char|
        if vovels.include?(char.downcase)
            counter[char.downcase] +=1
        end
    end
    return counter
end

